To use:
In Roms create a folder titled .media
SD/Roms/.media/

In the .media folder place the icons and rename them to match your folder for each systems roms